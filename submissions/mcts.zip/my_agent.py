"""
MCTS Sailing Agent
==================
Agent de planification par Monte Carlo Tree Search (MCTS) pour le Sailing Challenge.

Stratégie :
-----------
Au lieu d'apprendre une politique offline (difficile avec reward sparse),
on fait de la planification en ligne à chaque step :

1. On simule la physique exacte de l'environnement (position + vitesse + vent)
   pour explorer des séquences d'actions candidates.
2. Le vent est modélisé avec sa rotation moyenne attendue (mu_rotation) à chaque step
   simulé – c'est une prédiction déterministe suffisamment bonne sur 10-20 steps.
3. Windmaster sert de politique de rollout : après la phase d'expansion MCTS,
   on laisse windmaster piloter le reste du rollout pour obtenir un score terminal.
4. UCB1 guide la sélection pour équilibrer exploration/exploitation entre les branches.

Avantages vs PPO/AWAC :
-  Pas de training : pas d'instabilité, pas de mode collapse.
-  Utilise directement la physique de l'env → très précis dans ses prédictions.
-  Windmaster (déjà bon) guide les rollouts → convergence rapide vers de bonnes actions.
-  Adaptatif au vent test inconnu : re-plan à chaque step avec le vrai champ de vent observé.

Paramètres clés (modifiables) :
-  n_simulations   : nombre de simulations MCTS par step (200-500 selon le timeout)
-  max_depth       : profondeur maximale d'expansion (10-20 steps)
-  rollout_depth   : profondeur du rollout windmaster après expansion (20-40 steps)
-  c_puct          : constante d'exploration UCB1 (1.4 standard)

Numpy only – compatible avec l'évaluation Codabench (pas de PyTorch).
"""

import numpy as np
import math

try:
    from base_agent import BaseAgent
except ImportError:
    try:
        from evaluator.base_agent import BaseAgent
    except ImportError:
        from src.agents.base_agent import BaseAgent


# ---------------------------------------------------------------------------
# Physique de l'environnement (réplication exacte de env_sailing.py)
# ---------------------------------------------------------------------------

def _calculate_sailing_efficiency(boat_direction, wind_direction):
    """Réplique exacte de sailing_physics.calculate_sailing_efficiency."""
    wind_from = -wind_direction
    wind_angle = np.arccos(np.clip(np.dot(wind_from, boat_direction), -1.0, 1.0))
    if wind_angle < np.pi / 4:
        return 0.05
    elif wind_angle < np.pi / 2:
        return 0.5 + 0.5 * (wind_angle - np.pi / 4) / (np.pi / 4)
    elif wind_angle < 3 * np.pi / 4:
        return 1.0
    else:
        return max(0.5, 1.0 - 0.5 * (wind_angle - 3 * np.pi / 4) / (np.pi / 4))


def _step_physics(pos, vel, wind_field, action_dir,
                  boat_performance=0.4, max_speed=8.0, inertia_factor=0.3):
    """
    Simule un step de physique et retourne (new_pos, new_vel).
    Réplique exacte de SailingEnv._calculate_new_velocity + update position.
    """
    x, y = int(round(pos[0])), int(round(pos[1]))
    x = np.clip(x, 0, 127)
    y = np.clip(y, 0, 127)
    wind = wind_field[y, x]

    wind_norm = np.linalg.norm(wind)
    if wind_norm > 1e-6:
        wind_n = wind / wind_norm
        dir_norm = np.linalg.norm(action_dir)
        if dir_norm < 1e-10:
            dir_n = np.array([1.0, 0.0])
        else:
            dir_n = action_dir / dir_norm

        eff = _calculate_sailing_efficiency(dir_n, wind_n)
        theo_vel = action_dir * eff * wind_norm * boat_performance
        speed = np.linalg.norm(theo_vel)
        if speed > max_speed:
            theo_vel = theo_vel / speed * max_speed
        new_vel = theo_vel + inertia_factor * (vel - theo_vel)
        speed2 = np.linalg.norm(new_vel)
        if speed2 > max_speed:
            new_vel = new_vel / speed2 * max_speed
    else:
        new_vel = inertia_factor * vel

    # Discrétisation (exacte de l'env)
    new_vel_disc = np.where(new_vel < 0, np.ceil(new_vel), np.floor(new_vel)).astype(np.int32)
    new_pos = pos + new_vel_disc
    new_pos = np.clip(new_pos, [0, 0], [127, 127])
    return new_pos.astype(np.float32), new_vel_disc.astype(np.float32)


def _rotate_wind_field(wind_field, angle_deg):
    """Applique une rotation uniforme au champ de vent (prédiction déterministe)."""
    theta = np.deg2rad(angle_deg)
    cos_t, sin_t = np.cos(theta), np.sin(theta)
    x = wind_field[:, :, 0].copy()
    y = wind_field[:, :, 1].copy()
    new_wf = wind_field.copy()
    new_wf[:, :, 0] = x * cos_t - y * sin_t
    new_wf[:, :, 1] = x * sin_t + y * cos_t
    return new_wf


# ---------------------------------------------------------------------------
# Politique windmaster (rollout heuristique)
# ---------------------------------------------------------------------------

DIRECTIONS = np.array([
    [0, 1],   # 0: N
    [1, 1],   # 1: NE
    [1, 0],   # 2: E
    [1, -1],  # 3: SE
    [0, -1],  # 4: S
    [-1, -1], # 5: SW
    [-1, 0],  # 6: W
    [-1, 1],  # 7: NW
    [0, 0],   # 8: Stay
], dtype=float)

GOAL = np.array([64.0, 127.0])


def _windmaster_action(pos, vel, wind_field, world_map):
    """
    Réplique allégée de windmaster : choisit l'action maximisant le VMG
    vers l'objectif, avec sécurité île.
    """
    x, y = int(round(pos[0])), int(round(pos[1]))
    x = np.clip(x, 0, 127)
    y = np.clip(y, 0, 127)
    wind = wind_field[y, x]

    to_goal = GOAL - pos
    dist = np.linalg.norm(to_goal)
    if dist < 1e-6:
        return 8
    target_dir = to_goal / dist
    is_final = dist < 5.0

    best_action, best_score = 8, -np.inf

    for i in range(9):
        action_dir = DIRECTIONS[i]
        new_pos, pred_vel = _step_physics(pos, vel, wind_field, action_dir)
        nx, ny = int(round(new_pos[0])), int(round(new_pos[1]))
        nx = np.clip(nx, 0, 127)
        ny = np.clip(ny, 0, 127)

        if world_map[ny, nx] == 1:
            continue

        if is_final:
            new_dist = np.linalg.norm(GOAL - new_pos)
            future_speed = np.linalg.norm(pred_vel)
            score = -new_dist - future_speed * 0.1
            if new_dist < 1.5:
                score += 1000.0
        else:
            vmg = np.dot(pred_vel.astype(float), target_dir)
            safety = 1.0
            for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                nnx = np.clip(nx + dx, 0, 127)
                nny = np.clip(ny + dy, 0, 127)
                if world_map[nny, nnx] == 1:
                    safety = 0.2
                    break
            score = vmg * safety

        if score > best_score:
            best_score = score
            best_action = i

    return best_action


# ---------------------------------------------------------------------------
# Simulation d'un état complet (pour MCTS)
# ---------------------------------------------------------------------------

class SimState:
    """État simulé léger pour le MCTS."""
    __slots__ = ['pos', 'vel', 'wind_field', 'step', 'done', 'crashed', 'reached']

    def __init__(self, pos, vel, wind_field, step=0, done=False, crashed=False, reached=False):
        self.pos = pos.copy()
        self.vel = vel.copy()
        self.wind_field = wind_field  # partagé tant que non muté
        self.step = step
        self.done = done
        self.crashed = crashed
        self.reached = reached

    def clone(self):
        return SimState(self.pos.copy(), self.vel.copy(),
                        self.wind_field.copy(), self.step,
                        self.done, self.crashed, self.reached)


def _sim_step(state, action, world_map, mean_rotation_deg):
    """
    Applique une action à l'état simulé et retourne le nouvel état.
    Le vent est prédit en appliquant la rotation moyenne.
    """
    if state.done:
        return state.clone()

    action_dir = DIRECTIONS[action]
    new_pos, new_vel = _step_physics(state.pos, state.vel, state.wind_field, action_dir)

    nx, ny = int(round(new_pos[0])), int(round(new_pos[1]))
    nx = np.clip(nx, 0, 127)
    ny = np.clip(ny, 0, 127)

    # Vérification collision
    crashed = bool(world_map[ny, nx] == 1)
    dist = np.linalg.norm(GOAL - new_pos)
    reached = dist < 1.5

    # Rotation du vent (prédiction déterministe)
    new_wf = _rotate_wind_field(state.wind_field, mean_rotation_deg)

    new_state = SimState(
        pos=new_pos, vel=new_vel,
        wind_field=new_wf,
        step=state.step + 1,
        done=crashed or reached,
        crashed=crashed,
        reached=reached
    )
    return new_state


# ---------------------------------------------------------------------------
# Heuristique de valeur terminale
# ---------------------------------------------------------------------------

def _heuristic_value(state, gamma=0.995):
    """
    Estime la valeur d'un état terminal ou de fin de rollout.
    """
    if state.crashed:
        return -1.0  # collision = mauvais
    if state.reached:
        # Récompense discountée selon le step
        return 100.0 * (gamma ** state.step)
    # Non terminal : score de proximité
    dist = np.linalg.norm(GOAL - state.pos)
    # Normaliser : dist max ~ 127*sqrt(2) ≈ 180
    return max(0.0, (180.0 - dist) / 180.0) * 10.0


# ---------------------------------------------------------------------------
# Nœud MCTS
# ---------------------------------------------------------------------------

class MCTSNode:
    """Nœud de l'arbre MCTS (UCB1)."""
    __slots__ = ['state', 'parent', 'action', 'children',
                 'n_visits', 'total_value', 'untried_actions']

    def __init__(self, state, parent=None, action=None):
        self.state = state
        self.parent = parent
        self.action = action
        self.children = {}          # action -> MCTSNode
        self.n_visits = 0
        self.total_value = 0.0
        self.untried_actions = list(range(9))

    def ucb1(self, c=1.414):
        if self.n_visits == 0:
            return float('inf')
        exploit = self.total_value / self.n_visits
        explore = c * math.sqrt(math.log(self.parent.n_visits) / self.n_visits)
        return exploit + explore

    def is_fully_expanded(self):
        return len(self.untried_actions) == 0

    def best_child(self, c=1.414):
        return max(self.children.values(), key=lambda ch: ch.ucb1(c))

    def best_action(self):
        """Retourne l'action de l'enfant le plus visité (exploitation pure)."""
        return max(self.children, key=lambda a: self.children[a].n_visits)


# ---------------------------------------------------------------------------
# Agent MCTS principal
# ---------------------------------------------------------------------------

class MyAgent(BaseAgent):
    """
    Agent MCTS pour le Sailing Challenge.

    Paramètres :
    ------------
    n_simulations   : nombre de simulations MCTS par step (défaut: 300)
    max_depth       : profondeur d'expansion MCTS (défaut: 15)
    rollout_depth   : profondeur du rollout windmaster (défaut: 30)
    c_puct          : constante UCB1 (défaut: 1.414)
    mean_rotation   : rotation moyenne du vent par step (deg, défaut: 3.0)
    gamma           : discount factor pour la valeur (défaut: 0.995)
    """

    def __init__(self,
                 n_simulations=100,
                 max_depth=15,
                 rollout_depth=5,
                 c_puct=1.414,
                 mean_rotation=3.0,
                 gamma=0.995):
        super().__init__()
        self.n_simulations = n_simulations
        self.max_depth = max_depth
        self.rollout_depth = rollout_depth
        self.c_puct = c_puct
        self.mean_rotation = mean_rotation
        self.gamma = gamma

        self.world_map = None
        self._step_count = 0

    # ------------------------------------------------------------------
    # Interface BaseAgent
    # ------------------------------------------------------------------

    def reset(self):
        self.world_map = None
        self._step_count = 0

    def seed(self, seed=None):
        self.np_random = np.random.default_rng(seed)

    def save(self, path):
        # Pas de paramètres à sauvegarder (agent sans apprentissage offline)
        pass

    def load(self, path):
        pass

    # ------------------------------------------------------------------
    # Parsing de l'observation
    # ------------------------------------------------------------------

    def _parse_obs(self, observation):
        pos = observation[0:2].copy().astype(np.float32)
        vel = observation[2:4].copy().astype(np.float32)
        # Champ de vent : indices 6 à 6+128*128*2
        wind_flat = observation[6:6 + 128 * 128 * 2]
        wind_field = wind_flat.reshape(128, 128, 2).astype(np.float32)
        # World map : après le champ de vent
        world_flat = observation[6 + 128 * 128 * 2:]
        if self.world_map is None:
            self.world_map = world_flat.reshape(128, 128).astype(np.float32)
        return pos, vel, wind_field

    # ------------------------------------------------------------------
    # MCTS
    # ------------------------------------------------------------------

    def _rollout(self, state):
        """
        Rollout guidé par windmaster depuis un état simulé.
        Retourne la valeur estimée.
        """
        s = state.clone()
        for _ in range(self.rollout_depth):
            if s.done:
                break
            action = _windmaster_action(s.pos, s.vel, s.wind_field, self.world_map)
            s = _sim_step(s, action, self.world_map, self.mean_rotation)
        return _heuristic_value(s, self.gamma)

    def _mcts(self, root_state):
        """
        Lance n_simulations itérations MCTS depuis root_state.
        Retourne l'action recommandée.
        """
        root = MCTSNode(root_state)

        for _ in range(self.n_simulations):
            # 1. Sélection
            node = root
            depth = 0
            while not node.state.done and node.is_fully_expanded() and depth < self.max_depth:
                node = node.best_child(self.c_puct)
                depth += 1

            # 2. Expansion
            if not node.state.done and not node.is_fully_expanded():
                action = node.untried_actions.pop(
                    np.random.randint(len(node.untried_actions))
                )
                new_state = _sim_step(node.state, action, self.world_map, self.mean_rotation)
                child = MCTSNode(new_state, parent=node, action=action)
                node.children[action] = child
                node = child

            # 3. Rollout (simulation windmaster)
            value = self._rollout(node.state)

            # 4. Rétropropagation
            while node is not None:
                node.n_visits += 1
                node.total_value += value
                node = node.parent

        if not root.children:
            # Fallback windmaster si MCTS n'a rien exploré
            return _windmaster_action(
                root_state.pos, root_state.vel, root_state.wind_field, self.world_map
            )

        return root.best_action()

    # ------------------------------------------------------------------
    # act
    # ------------------------------------------------------------------

    def act(self, observation: np.ndarray) -> int:
        pos, vel, wind_field = self._parse_obs(observation)
        self._step_count += 1

        # Construire l'état simulé initial (correspondant à l'obs reçue)
        root_state = SimState(
            pos=pos,
            vel=vel,
            wind_field=wind_field,
            step=self._step_count
        )
        # Vérifier si déjà arrivé (ne devrait pas arriver, mais sécurité)
        dist = np.linalg.norm(GOAL - pos)
        if dist < 1.5:
            return 8  # Stay

        action = self._mcts(root_state)
        return int(action)